# Importing the libraries
import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
import plotly.graph_objs as go

# Header
st.header("Diabetes Data Set Web App")
st.write("This app will explore different relations in the Diabetes Data Set")

# Load the diabetes dataset into a Pandas DataFrame
data = pd.read_csv('diabetes-data.csv')

#------------------------------------------------------------------------------------------
# Graph : 1
import pandas as pd
import plotly.express as px
import streamlit as st

# Load the data from CSV file
df = pd.read_csv("diabetes-data.csv")

# Filter the data based on the required columns
data = df.loc[:, ["Age", "Diabetes"]]

# Create age categories
age_categories = ["18-24", "25-29", "30-34", "35-39", "40-44", "45-49", "50-54", "55-59", "60-64", "65-69", "70-74", "75-79", "80+"]

# Group the data by age and diabetes status
grouped_data = data.groupby(["Age", "Diabetes"]).size().reset_index(name="Count")

# Pivot the data to create a bar graph
pivoted_data = grouped_data.pivot(index="Age", columns="Diabetes", values="Count")
pivoted_data = pivoted_data.fillna(0)

# Create the bar graph
fig = px.bar(pivoted_data, x=age_categories, y=[0, 1], barmode="group",
             labels={"value": "Count", "variable": "Diabetes", "x": "Age"})

# Update the legend names
fig.data[0].name = 'No Diabetes'
fig.data[1].name = 'Diabetes'

# Set the title
fig.update_layout(title="Age with Diabetes")

# Add a slider to select the range of age
min_age = int(data['Age'].min())
max_age = int(data['Age'].max())

age_range = st.slider("Select Age Range", min_value=min_age, max_value=max_age, value=(min_age, max_age))

# Filter the data based on the selected age range
filtered_data = data[(data['Age'] >= age_range[0]) & (data['Age'] <= age_range[1])]

# Group the filtered data by age and diabetes status
grouped_data = filtered_data.groupby(["Age", "Diabetes"]).size().reset_index(name="Count")

# Pivot the filtered data to create a bar graph
pivoted_data = grouped_data.pivot(index="Age", columns="Diabetes", values="Count")
pivoted_data = pivoted_data.fillna(0)

# Update the bar graph data based on the filtered data
fig.data[0].y = pivoted_data[0].values.tolist()
fig.data[1].y = pivoted_data[1].values.tolist()

# Display the bar graph using Streamlit
st.plotly_chart(fig)

#------------------------------------------------------------------------------------------

# Graph : 2

import pandas as pd
import plotly.express as px
import streamlit as st

# Load the dataset
df = pd.read_csv("diabetes-data.csv")

# Define the minimum and maximum BMI values
min_bmi = df['BMI'].min()
max_bmi = df['BMI'].max()

# Add a slider to select the range of BMI
bmi_range = st.slider("Select a range of BMI", int(min_bmi), int(max_bmi), (int(min_bmi), int(max_bmi)))

# Filter the data based on the selected BMI range
filtered_data = df[(df['BMI'] >= bmi_range[0]) & (df['BMI'] <= bmi_range[1])]

# Group the data by BMI and diabetes status
grouped_data = filtered_data.groupby(["BMI", "Diabetes"]).size().reset_index(name="Count")

# Pivot the data to create a bar graph
pivoted_data = grouped_data.pivot(index="BMI", columns="Diabetes", values="Count")
pivoted_data = pivoted_data.fillna(0)

# Create the bar graph
fig = px.bar(pivoted_data, barmode="group",
             labels={"value": "Count", "variable": "Diabetes", "x": "BMI"})

# Update the legend names
fig.data[0].name = 'No Diabetes'
fig.data[1].name = 'Diabetes'

# Set the title
fig.update_layout(title="BMI with Diabetes")

# Display the bar graph using Streamlit
st.plotly_chart(fig)





#------------------------------------------------------------------------------------------

# Graph : 3

import streamlit as st
import pandas as pd
import plotly.graph_objs as go

# Load data from CSV file
df = pd.read_csv('diabetes-data.csv')

# Get unique values of GenHlth for dropdown menu
genhlth_options = df['GenHlth'].unique()

# Create dropdown menu for selecting GenHlth
selected_genhlth = st.selectbox('Select GenHlth', genhlth_options)

# Group the data by GenHlth and Diabetes, and calculate the mean HighBP value for each group
means = df.groupby(['GenHlth', 'Diabetes'])['HighBP'].mean().reset_index()

# Filter the data based on selected GenHlth
filtered_means = means[means['GenHlth'] == selected_genhlth]

# Create a pivot table with GenHlth as rows, Diabetes as columns, and mean HighBP as values
pivot = filtered_means.pivot(index='GenHlth', columns='Diabetes', values='HighBP')

# Create the plot using Plotly
fig = go.Figure(data=[
    go.Bar(name='Diabetes', x=pivot.index, y=pivot[1], marker_color='#FFA500'),
    go.Bar(name='Non-Diabetes', x=pivot.index, y=pivot[0], marker_color='#1f77b4')
])

# Set layout properties
fig.update_layout(
    title='Genral Health with respect to Diabetes and HighBP',
    xaxis_title='GenHlth',
    yaxis_title='HighBP',
    barmode='group',
    bargap=0.15,
    bargroupgap=0.1
)

# Display the plot using Streamlit
st.plotly_chart(fig)

#------------------------------------------------------------------------------------------
# Graph : 4

import streamlit as st
import pandas as pd
import plotly.graph_objects as go

# Load the data from CSV file
df = pd.read_csv("diabetes-data.csv")

# Filter the data based on the required columns
data = df.loc[:, ["HighBP", "BMI", "Diabetes"]]

# Create separate DataFrames for Diabetes=0 and Diabetes=1 groups
nondiabetic = df[df['Diabetes'] == 0]
diabetic = df[df['Diabetes'] == 1]

# Box plot for nondiabetic
nondiabetic_0 = nondiabetic[nondiabetic['HighBP'] == 0]['BMI']
nondiabetic_1 = nondiabetic[nondiabetic['HighBP'] == 1]['BMI']
box1 = go.Box(y=nondiabetic_0, name='Non-Diabetic (0 HighBP)', boxmean=True, marker_color='orange')
box2 = go.Box(y=nondiabetic_1, name='Non-Diabetic (1 HighBP)', boxmean=True, marker_color='orange')

# Box plot for diabetic
diabetic_0 = diabetic[diabetic['HighBP'] == 0]['BMI']
diabetic_1 = diabetic[diabetic['HighBP'] == 1]['BMI']
box3 = go.Box(y=diabetic_0, name='Diabetic (0 HighBP)', boxmean=True, marker_color='blue')
box4 = go.Box(y=diabetic_1, name='Diabetic (1 HighBP)', boxmean=True, marker_color='blue')

# Create the plot
fig = go.Figure(data=[box1, box2, box3, box4])

# Set axis labels and title
fig.update_layout(xaxis=dict(tickmode='array',  ticktext=['0 HighBP', '1 HighBP']),
                  yaxis=dict(title='BMI'),
                  title='HighBP with BMI and Diabetes')

# Show the plot using Streamlit
st.plotly_chart(fig, use_container_width=True)

#------------------------------------------------------------------------------------------

import pandas as pd
import plotly.graph_objs as go
import streamlit as st

# load the dataset
df = pd.read_csv('diabetes-data.csv')

# create a correlation matrix
corr = df.corr()

# extract the correlation values for diabetes
corr_diabetes = corr['Diabetes']

# get the list of attribute names
attributes = df.columns.tolist()
attributes.remove('Diabetes')

# create a multiselect widget for selecting attributes
selected_attributes = st.sidebar.multiselect('Select attributes', attributes, [])

# filter the correlation data for the selected attributes
if len(selected_attributes) > 0:
    corr_diabetes = corr_diabetes.loc[selected_attributes]

# create a Plotly figure of the correlations
fig = go.Figure(data=go.Scatter(x=corr_diabetes.index, y=corr_diabetes.values, mode='lines'))
fig.add_hline(y=0, line=dict(color='red', width=1, dash='solid'))

fig.update_layout(
    xaxis_tickangle=-45,
    xaxis_title='Attributes',
    yaxis_title='Correlation',
    title='Correlation of Diabetes with other attributes'
)

st.plotly_chart(fig)






